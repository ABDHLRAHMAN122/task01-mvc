﻿using Microsoft.AspNetCore.Mvc;
using test.Models;

namespace test.Controllers
{
    public class StudentController : Controller
    {

        private static List<Student> students = new List<Student>
        {
            new Student { Id = 1, Name = "Ahmed", Track = "Computer Science" },
            new Student { Id = 2, Name = "Sara", Track = "Software Engineering" }
        };

        // 1. إرجاع صفحة HTML (ViewResult)
        // الرابط: /Student/Index
        public IActionResult Index()
        {
            return View(students);
        }

        // 2. إرجاع بيانات بصيغة جيسون (JsonResult) - مفيد للتعامل مع الـ APIs
        // الرابط: /Student/GetJsonData
        public IActionResult GetJsonData()
        {
            return Json(students);
        }

        // 3. إعادة التوجيه إلى إجراء آخر (RedirectToActionResult)
        // الرابط: /Student/GoHome
        public IActionResult GoHome()
        {
            return RedirectToAction("Index", "Home");
        }

    }
}
