﻿

using Microsoft.AspNetCore.Mvc;

namespace test.Models
{
    public class Student 
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string Track { get; set; }
    }
}
